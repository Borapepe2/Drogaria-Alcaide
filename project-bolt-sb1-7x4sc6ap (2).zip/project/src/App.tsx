import React, { useState } from 'react';
import { SprayCan as Spray, Wrench, Phone, Clock, MapPin, Search, ShoppingCart, Menu, X, ChevronRight, Star, Package, Shield, Hammer, Paintbrush } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount] = useState(0);

  return (
    <div className="min-h-screen bg-white">
      {/* Top Bar */}
      <div className="bg-gray-100 py-2 text-sm">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Phone size={14} className="text-blue-600" />
                <span>(351) 123-456-789</span>
              </div>
              <div className="hidden md:flex items-center gap-1">
                <Clock size={14} className="text-blue-600" />
                <span>Seg-Sáb: 9h-19h</span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <MapPin size={14} className="text-blue-600" />
              <span>Rua Principal, 123 - Lisboa</span>
            </div>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button 
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            <div className="flex items-center gap-2">
              <div className="flex items-center">
                <Spray className="h-8 w-8 text-blue-600" />
                <Wrench className="h-8 w-8 text-red-600 -ml-2" />
              </div>
              <h1 className="text-2xl font-bold">DrogaFerra</h1>
            </div>

            <div className="hidden lg:flex flex-1 max-w-2xl mx-12">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="O que procura hoje?"
                  className="w-full px-4 py-2 pl-10 rounded-lg border border-gray-200 focus:outline-none focus:border-blue-500"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
              </div>
            </div>

            <div className="relative">
              <ShoppingCart size={24} className="text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div className={`lg:hidden ${isMenuOpen ? 'block' : 'hidden'} border-b`}>
        <nav className="container mx-auto px-4 py-4">
          <div className="flex flex-col space-y-2">
            <a href="#" className="flex items-center justify-between py-2 hover:text-blue-600">
              Limpeza <ChevronRight size={16} />
            </a>
            <a href="#" className="flex items-center justify-between py-2 hover:text-blue-600">
              Ferramentas <ChevronRight size={16} />
            </a>
            <a href="#" className="flex items-center justify-between py-2 hover:text-blue-600">
              Pintura <ChevronRight size={16} />
            </a>
            <a href="#" className="flex items-center justify-between py-2 hover:text-blue-600">
              Bricolage <ChevronRight size={16} />
            </a>
          </div>
        </nav>
      </div>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-900 to-gray-800 py-20">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10"></div>
        </div>
        <div className="container mx-auto px-4 relative">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Tudo para sua casa e projetos
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Produtos de limpeza, ferramentas e materiais de construção com qualidade garantida
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition">
                Ver Produtos
              </button>
              <button className="bg-white text-gray-900 px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition">
                Novidades
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4">
              <Package className="h-10 w-10 text-blue-600" />
              <div>
                <h3 className="font-semibold">Atendimento Especializado</h3>
                <p className="text-sm text-gray-600">Equipe técnica qualificada</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Shield className="h-10 w-10 text-blue-600" />
              <div>
                <h3 className="font-semibold">Garantia de Qualidade</h3>
                <p className="text-sm text-gray-600">Produtos certificados</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Star className="h-10 w-10 text-blue-600" />
              <div>
                <h3 className="font-semibold">Programa Fidelidade</h3>
                <p className="text-sm text-gray-600">Ganhe pontos em compras</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Categorias em Destaque</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Limpeza */}
            <div className="group relative overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&q=80"
                alt="Produtos de Limpeza"
                className="w-full h-80 object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Produtos de Limpeza</h3>
                  <button className="text-white flex items-center gap-2 group-hover:gap-3 transition-all">
                    Ver Produtos <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* Ferramentas */}
            <div className="group relative overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1581244277943-fe4a9c777189?auto=format&fit=crop&q=80"
                alt="Ferramentas"
                className="w-full h-80 object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Ferramentas</h3>
                  <button className="text-white flex items-center gap-2 group-hover:gap-3 transition-all">
                    Ver Produtos <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* Pintura */}
            <div className="group relative overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&q=80"
                alt="Pintura"
                className="w-full h-80 object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Pintura</h3>
                  <button className="text-white flex items-center gap-2 group-hover:gap-3 transition-all">
                    Ver Produtos <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Produtos em Destaque</h2>
            <button className="text-blue-600 font-medium flex items-center gap-2">
              Ver Todos <ChevronRight size={16} />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="bg-white rounded-lg p-4 group hover:shadow-lg transition">
                <div className="relative mb-4">
                  <img
                    src={`https://source.unsplash.com/random/400x400?tools,cleaning&sig=${item}`}
                    alt="Product"
                    className="w-full aspect-square object-cover rounded-lg"
                  />
                  <button className="absolute top-2 right-2 bg-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition">
                    <ShoppingCart size={18} />
                  </button>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Produto {item}</h3>
                  <div className="flex items-center gap-1 mb-2">
                    {Array(5).fill(null).map((_, i) => (
                      <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold">€9,90</span>
                    <span className="text-sm text-gray-500 line-through">€12,90</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Explore Nossas Categorias</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              { icon: Spray, name: 'Limpeza', count: 128 },
              { icon: Hammer, name: 'Ferramentas', count: 95 },
              { icon: Paintbrush, name: 'Pintura', count: 64 },
              { icon: Package, name: 'Bricolage', count: 73 },
              { icon: Shield, name: 'Proteção', count: 42 },
              { icon: Wrench, name: 'Manutenção', count: 86 },
              { icon: Star, name: 'Novidades', count: 31 },
              { icon: Package, name: 'Acessórios', count: 159 },
            ].map((category, index) => (
              <a
                key={index}
                href="#"
                className="flex flex-col items-center p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition"
              >
                <category.icon className="h-8 w-8 text-blue-600 mb-3" />
                <h3 className="font-medium text-center">{category.name}</h3>
                <span className="text-sm text-gray-500">{category.count} produtos</span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="flex items-center">
                  <Spray className="h-8 w-8 text-blue-500" />
                  <Wrench className="h-8 w-8 text-red-500 -ml-2" />
                </div>
                <h3 className="text-2xl font-bold text-white">DrogaFerra</h3>
              </div>
              <p className="text-gray-400 mb-6">
                A sua loja de confiança para produtos de limpeza e ferragens em Lisboa.
              </p>
              <div className="flex items-center gap-4">
                <a href="#" className="hover:text-white transition">Facebook</a>
                <a href="#" className="hover:text-white transition">Instagram</a>
                <a href="#" className="hover:text-white transition">LinkedIn</a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Categorias</h4>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition">Limpeza</a></li>
                <li><a href="#" className="hover:text-white transition">Ferramentas</a></li>
                <li><a href="#" className="hover:text-white transition">Pintura</a></li>
                <li><a href="#" className="hover:text-white transition">Bricolage</a></li>
                <li><a href="#" className="hover:text-white transition">Proteção</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Informações</h4>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition">Sobre Nós</a></li>
                <li><a href="#" className="hover:text-white transition">Contactos</a></li>
                <li><a href="#" className="hover:text-white transition">Política de Privacidade</a></li>
                <li><a href="#" className="hover:text-white transition">Termos e Condições</a></li>
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Contacto</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <MapPin size={16} />
                  Rua Principal, 123, Lisboa
                </li>
                <li className="flex items-center gap-2">
                  <Phone size={16} />
                  (351) 123-456-789
                </li>
                <li className="flex items-center gap-2">
                  <Clock size={16} />
                  Seg-Sáb: 9h-19h
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p>&copy; 2024 DrogaFerra. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;